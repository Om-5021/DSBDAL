**NOTE:**

The dataset used for this practical was collected by us. You can use a diffrent dataset.
